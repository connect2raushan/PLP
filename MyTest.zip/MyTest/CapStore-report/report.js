$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("E:/Workplace/MyTest/src/test/java/com/cg/MyTest/feature/CapStoreSignUp.feature");
formatter.feature({
  "line": 1,
  "name": "To test coaching enquiry form elements",
  "description": "this feature is for testing all the elements in the coaching enquiry form",
  "id": "to-test-coaching-enquiry-form-elements",
  "keyword": "Feature"
});
formatter.background({
  "line": 4,
  "name": "launch the coaching enquiry form",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 5,
  "name": "user is on coaching enquiry form",
  "keyword": "Given "
});
formatter.match({
  "location": "CapStoreSignupStepDf.user_is_on_coaching_enquiry_form()"
});
formatter.result({
  "duration": 13331724166,
  "status": "passed"
});
formatter.scenario({
  "line": 7,
  "name": "to verify the title of the page",
  "description": "",
  "id": "to-test-coaching-enquiry-form-elements;to-verify-the-title-of-the-page",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 8,
  "name": "check the title of the page",
  "keyword": "Then "
});
formatter.match({
  "location": "CapStoreSignupStepDf.check_the_title_of_the_page()"
});
formatter.result({
  "duration": 34264101,
  "status": "passed"
});
formatter.after({
  "duration": 2191135585,
  "status": "passed"
});
formatter.background({
  "line": 4,
  "name": "launch the coaching enquiry form",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 5,
  "name": "user is on coaching enquiry form",
  "keyword": "Given "
});
formatter.match({
  "location": "CapStoreSignupStepDf.user_is_on_coaching_enquiry_form()"
});
formatter.result({
  "duration": 10076275329,
  "status": "passed"
});
formatter.scenario({
  "line": 10,
  "name": "to verify the text on the page",
  "description": "",
  "id": "to-test-coaching-enquiry-form-elements;to-verify-the-text-on-the-page",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 11,
  "name": "check if text is present",
  "keyword": "Then "
});
formatter.match({
  "location": "CapStoreSignupStepDf.check_if_text_is_present()"
});
formatter.result({
  "duration": 102836058,
  "status": "passed"
});
formatter.after({
  "duration": 2146196631,
  "status": "passed"
});
formatter.background({
  "line": 4,
  "name": "launch the coaching enquiry form",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 5,
  "name": "user is on coaching enquiry form",
  "keyword": "Given "
});
formatter.match({
  "location": "CapStoreSignupStepDf.user_is_on_coaching_enquiry_form()"
});
formatter.result({
  "duration": 10395219598,
  "status": "passed"
});
formatter.scenario({
  "line": 13,
  "name": "check for alert if name text box is empty",
  "description": "",
  "id": "to-test-coaching-enquiry-form-elements;check-for-alert-if-name-text-box-is-empty",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 14,
  "name": "fill form data except name",
  "keyword": "Given "
});
formatter.step({
  "line": 15,
  "name": "click on submit",
  "keyword": "And "
});
formatter.step({
  "line": 16,
  "name": "switch to alert and accept it",
  "keyword": "Then "
});
formatter.match({
  "location": "CapStoreSignupStepDf.fill_form_data_except_name()"
});
formatter.result({
  "duration": 5313866125,
  "status": "passed"
});
formatter.match({
  "location": "CapStoreSignupStepDf.click_on_submit()"
});
formatter.result({
  "duration": 3150016178,
  "status": "passed"
});
formatter.match({
  "location": "CapStoreSignupStepDf.switch_to_alert_and_accept_it()"
});
formatter.result({
  "duration": 2028210410,
  "status": "passed"
});
formatter.after({
  "duration": 2198028701,
  "status": "passed"
});
formatter.background({
  "line": 4,
  "name": "launch the coaching enquiry form",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 5,
  "name": "user is on coaching enquiry form",
  "keyword": "Given "
});
formatter.match({
  "location": "CapStoreSignupStepDf.user_is_on_coaching_enquiry_form()"
});
formatter.result({
  "duration": 10880886981,
  "status": "passed"
});
formatter.scenario({
  "line": 18,
  "name": "check for alert if email is empty",
  "description": "",
  "id": "to-test-coaching-enquiry-form-elements;check-for-alert-if-email-is-empty",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 19,
  "name": "fill form data except email empty",
  "keyword": "Given "
});
formatter.step({
  "line": 20,
  "name": "click on submit",
  "keyword": "And "
});
formatter.step({
  "line": 21,
  "name": "switch to alert and accept it",
  "keyword": "Then "
});
formatter.match({
  "location": "CapStoreSignupStepDf.fill_form_data_except_email_empty()"
});
formatter.result({
  "duration": 5190851455,
  "status": "passed"
});
formatter.match({
  "location": "CapStoreSignupStepDf.click_on_submit()"
});
formatter.result({
  "duration": 3118449689,
  "status": "passed"
});
formatter.match({
  "location": "CapStoreSignupStepDf.switch_to_alert_and_accept_it()"
});
formatter.result({
  "duration": 2035097044,
  "status": "passed"
});
formatter.after({
  "duration": 2178307073,
  "status": "passed"
});
formatter.background({
  "line": 4,
  "name": "launch the coaching enquiry form",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 5,
  "name": "user is on coaching enquiry form",
  "keyword": "Given "
});
formatter.match({
  "location": "CapStoreSignupStepDf.user_is_on_coaching_enquiry_form()"
});
formatter.result({
  "duration": 9632536528,
  "status": "passed"
});
formatter.scenario({
  "line": 23,
  "name": "check for alert if mobile is empty",
  "description": "",
  "id": "to-test-coaching-enquiry-form-elements;check-for-alert-if-mobile-is-empty",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 24,
  "name": "fill form data except mobile",
  "keyword": "Given "
});
formatter.step({
  "line": 25,
  "name": "click on submit",
  "keyword": "And "
});
formatter.step({
  "line": 26,
  "name": "switch to alert and accept it",
  "keyword": "Then "
});
formatter.match({
  "location": "CapStoreSignupStepDf.fill_form_data_except_mobile()"
});
formatter.result({
  "duration": 5284103805,
  "status": "passed"
});
formatter.match({
  "location": "CapStoreSignupStepDf.click_on_submit()"
});
formatter.result({
  "duration": 3154938213,
  "status": "passed"
});
formatter.match({
  "location": "CapStoreSignupStepDf.switch_to_alert_and_accept_it()"
});
formatter.result({
  "duration": 2014756921,
  "status": "passed"
});
formatter.after({
  "duration": 2163572840,
  "status": "passed"
});
formatter.background({
  "line": 4,
  "name": "launch the coaching enquiry form",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 5,
  "name": "user is on coaching enquiry form",
  "keyword": "Given "
});
formatter.match({
  "location": "CapStoreSignupStepDf.user_is_on_coaching_enquiry_form()"
});
formatter.result({
  "duration": 10891748732,
  "status": "passed"
});
formatter.scenario({
  "line": 28,
  "name": "check for alert if address is empty",
  "description": "",
  "id": "to-test-coaching-enquiry-form-elements;check-for-alert-if-address-is-empty",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 29,
  "name": "fill form data except address",
  "keyword": "Given "
});
formatter.step({
  "line": 30,
  "name": "click on submit",
  "keyword": "And "
});
formatter.step({
  "line": 31,
  "name": "switch to alert and accept it",
  "keyword": "Then "
});
formatter.match({
  "location": "CapStoreSignupStepDf.fill_form_data_except_address()"
});
formatter.result({
  "duration": 5288938873,
  "status": "passed"
});
formatter.match({
  "location": "CapStoreSignupStepDf.click_on_submit()"
});
formatter.result({
  "duration": 3125753335,
  "status": "passed"
});
formatter.match({
  "location": "CapStoreSignupStepDf.switch_to_alert_and_accept_it()"
});
formatter.result({
  "duration": 2023169538,
  "status": "passed"
});
formatter.after({
  "duration": 2170288780,
  "status": "passed"
});
formatter.background({
  "line": 4,
  "name": "launch the coaching enquiry form",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 5,
  "name": "user is on coaching enquiry form",
  "keyword": "Given "
});
formatter.match({
  "location": "CapStoreSignupStepDf.user_is_on_coaching_enquiry_form()"
});
formatter.result({
  "duration": 9669357796,
  "status": "passed"
});
formatter.scenario({
  "line": 33,
  "name": "check for alert if password is empty",
  "description": "",
  "id": "to-test-coaching-enquiry-form-elements;check-for-alert-if-password-is-empty",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 34,
  "name": "fill form data except password",
  "keyword": "Given "
});
formatter.step({
  "line": 35,
  "name": "click on submit",
  "keyword": "And "
});
formatter.step({
  "line": 36,
  "name": "switch to alert and accept it",
  "keyword": "Then "
});
formatter.match({
  "location": "CapStoreSignupStepDf.fill_form_data_except_password()"
});
formatter.result({
  "duration": 5254633719,
  "status": "passed"
});
formatter.match({
  "location": "CapStoreSignupStepDf.click_on_submit()"
});
formatter.result({
  "duration": 3127374387,
  "status": "passed"
});
formatter.match({
  "location": "CapStoreSignupStepDf.switch_to_alert_and_accept_it()"
});
formatter.result({
  "duration": 2053503357,
  "status": "passed"
});
formatter.after({
  "duration": 2198339840,
  "status": "passed"
});
formatter.background({
  "line": 4,
  "name": "launch the coaching enquiry form",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 5,
  "name": "user is on coaching enquiry form",
  "keyword": "Given "
});
formatter.match({
  "location": "CapStoreSignupStepDf.user_is_on_coaching_enquiry_form()"
});
formatter.result({
  "duration": 9417290428,
  "status": "passed"
});
formatter.scenario({
  "line": 38,
  "name": "check for alert if question is empty",
  "description": "",
  "id": "to-test-coaching-enquiry-form-elements;check-for-alert-if-question-is-empty",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 39,
  "name": "fill form data except question",
  "keyword": "Given "
});
formatter.step({
  "line": 40,
  "name": "click on submit",
  "keyword": "And "
});
formatter.step({
  "line": 41,
  "name": "switch to alert and accept it",
  "keyword": "Then "
});
formatter.match({
  "location": "CapStoreSignupStepDf.fill_form_data_except_question()"
});
formatter.result({
  "duration": 5299804404,
  "status": "passed"
});
formatter.match({
  "location": "CapStoreSignupStepDf.click_on_submit()"
});
formatter.result({
  "duration": 3137049923,
  "status": "passed"
});
formatter.match({
  "location": "CapStoreSignupStepDf.switch_to_alert_and_accept_it()"
});
formatter.result({
  "duration": 2019786449,
  "status": "passed"
});
formatter.after({
  "duration": 2188673487,
  "status": "passed"
});
formatter.background({
  "line": 4,
  "name": "launch the coaching enquiry form",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 5,
  "name": "user is on coaching enquiry form",
  "keyword": "Given "
});
formatter.match({
  "location": "CapStoreSignupStepDf.user_is_on_coaching_enquiry_form()"
});
formatter.result({
  "duration": 9302877435,
  "status": "passed"
});
formatter.scenario({
  "line": 43,
  "name": "check for alert if answer is empty",
  "description": "",
  "id": "to-test-coaching-enquiry-form-elements;check-for-alert-if-answer-is-empty",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 44,
  "name": "fill form data except answer",
  "keyword": "Given "
});
formatter.step({
  "line": 45,
  "name": "click on submit",
  "keyword": "And "
});
formatter.step({
  "line": 46,
  "name": "switch to alert and accept it",
  "keyword": "Then "
});
formatter.match({
  "location": "CapStoreSignupStepDf.fill_form_data_except_answer()"
});
formatter.result({
  "duration": 5357082474,
  "status": "passed"
});
formatter.match({
  "location": "CapStoreSignupStepDf.click_on_submit()"
});
formatter.result({
  "duration": 3151473019,
  "status": "passed"
});
formatter.match({
  "location": "CapStoreSignupStepDf.switch_to_alert_and_accept_it()"
});
formatter.result({
  "duration": 2020202381,
  "status": "passed"
});
formatter.after({
  "duration": 2180813465,
  "status": "passed"
});
formatter.background({
  "line": 4,
  "name": "launch the coaching enquiry form",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 5,
  "name": "user is on coaching enquiry form",
  "keyword": "Given "
});
formatter.match({
  "location": "CapStoreSignupStepDf.user_is_on_coaching_enquiry_form()"
});
formatter.result({
  "duration": 9888824249,
  "status": "passed"
});
formatter.scenario({
  "line": 48,
  "name": "check for alert if wallet is empty",
  "description": "",
  "id": "to-test-coaching-enquiry-form-elements;check-for-alert-if-wallet-is-empty",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 49,
  "name": "fill form data except wallet",
  "keyword": "Given "
});
formatter.step({
  "line": 50,
  "name": "click on submit",
  "keyword": "And "
});
formatter.step({
  "line": 51,
  "name": "switch to alert and accept it",
  "keyword": "Then "
});
formatter.match({
  "location": "CapStoreSignupStepDf.fill_form_data_except_wallet()"
});
formatter.result({
  "duration": 5381393932,
  "status": "passed"
});
formatter.match({
  "location": "CapStoreSignupStepDf.click_on_submit()"
});
formatter.result({
  "duration": 3202024343,
  "status": "passed"
});
formatter.match({
  "location": "CapStoreSignupStepDf.switch_to_alert_and_accept_it()"
});
formatter.result({
  "duration": 2013446467,
  "status": "passed"
});
formatter.after({
  "duration": 2153063280,
  "status": "passed"
});
});