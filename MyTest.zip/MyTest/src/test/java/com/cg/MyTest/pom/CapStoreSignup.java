package com.cg.MyTest.pom;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class CapStoreSignup {
	WebDriver driver;
	@FindBy(how = How.NAME, using = "name")
	@CacheLookup
	private WebElement name;
	
	@FindBy(how = How.NAME, using = "email")
	@CacheLookup
	private WebElement email;
	
	@FindBy(how = How.NAME, using = "password")
	@CacheLookup
	private WebElement password;
	
	@FindBy(how = How.NAME, using = "contact")
	@CacheLookup
	private WebElement contact;
	
	@FindBy(how = How.NAME, using = "address")
	@CacheLookup
	private WebElement address;
	
	@FindBy(how = How.NAME, using = "question")
	@CacheLookup
	private WebElement question;
	
	@FindBy(how = How.NAME, using = "answer")
	@CacheLookup
	private WebElement answer;
	
	@FindBy(how = How.NAME, using = "balance")
	@CacheLookup
	private WebElement balance;
	
	@FindBy(how = How.NAME, using = "submit")
	@CacheLookup
	private WebElement submit;
	
	@FindBy(how = How.NAME, using = "reset")
	@CacheLookup
	private WebElement reset;
	
	@FindBy(how = How.NAME, using = "text")
	@CacheLookup
	private WebElement text;

	public WebDriver getDriver() {
		return driver;
	}

	public void setDriver(WebDriver driver) {
		this.driver = driver;
	}

	public WebElement getName() {
		return name;
	}

	public void setName(String name) {
		this.name.sendKeys(name);
	}

	public WebElement getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email.sendKeys(email);
	}

	public WebElement getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password.sendKeys(password);
	}

	public WebElement getContact() {
		return contact;
	}

	public void setContact(String contact) {
		this.contact.sendKeys(contact);
	}

	public WebElement getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address.sendKeys(address);
	}

	public WebElement getQuestion() {
		return question;
	}

	public void setQuestion(String question) {
		this.question.sendKeys(question);
	}

	public WebElement getAnswer() {
		return answer;
	}

	public void setAnswer(String answer) {
		this.answer.sendKeys(answer);
	}

	public WebElement getBalance() {
		return balance;
	}

	public void setBalance(String balance) {
		this.balance.sendKeys(balance);
	}

	public WebElement getSubmit() {
		return submit;
	}

	public void setSubmit() {
		this.submit.click();
	}

	public WebElement getReset() {
		return reset;
	}

	public void setReset() {
		this.reset.click();
	}
	
	public String getText() {
		return text.getText();
	}

	public void setText(WebElement text) {
		this.text=text;
	}

}
