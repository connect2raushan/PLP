package com.cg.MyTest;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(features = "E:\\Workplace\\MyTest\\src\\test\\java\\com\\cg\\MyTest\\feature\\CapStoreSignUp.feature",
glue = "com.cg.MyTest.stepDef",
plugin = {"pretty", "html:CapStore-report" }, 
monochrome = true)
public class AppTest 
{
}
