package com.cg.MyTest.stepDef;

import static org.junit.Assert.assertEquals;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import com.cg.MyTest.pom.CapStoreSignup;

import cucumber.api.java.After;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class CapStoreSignupStepDf {
	
	WebDriver driver;
	CapStoreSignup capStoreSignup;

@Given("^user is on coaching enquiry form$")
public void user_is_on_coaching_enquiry_form() throws InterruptedException {
	System.setProperty("webdriver.chrome.driver",
			"E:\\Workplace\\MyTest\\src\\test\\java\\Browser\\chromedriver.exe");
	driver = new ChromeDriver();
	Thread.sleep(5000);
	driver.get(
			"E:\\Workplace\\MyTest\\src\\test\\java\\com\\cg\\MyTest\\html\\user-form.component.html");
	capStoreSignup = PageFactory.initElements(driver, CapStoreSignup.class);
	driver.manage().window().maximize();
    
}

@Then("^check the title of the page$")
public void check_the_title_of_the_page()  {
	System.out.println("Title of the page : " + driver.getTitle());
	assertEquals("CapStore_Signup", driver.getTitle());
    
}

@Then("^check if text is present$")
public void check_if_text_is_present() throws InterruptedException {
	System.out.println("Text on the page : " + capStoreSignup.getText());
	assertEquals("CapStore", capStoreSignup.getText());
    
}

@Given("^fill form data except name$")
public void fill_form_data_except_name() throws InterruptedException {
	capStoreSignup.setName("");
	Thread.sleep(500);
	capStoreSignup.setEmail("raushanmishra@gmail.com");
	Thread.sleep(500);
	capStoreSignup.setPassword("connect2raushan");
	Thread.sleep(500);
	capStoreSignup.setAddress("Bangalore");
	Thread.sleep(500);
	capStoreSignup.setQuestion("pet name");
	Thread.sleep(500);
	capStoreSignup.setAnswer("google");
	Thread.sleep(500);
	capStoreSignup.setContact("7415417237");
	Thread.sleep(500);
	capStoreSignup.setBalance("500");
	Thread.sleep(500);
    
}

@Given("^click on submit$")
public void click_on_submit() throws InterruptedException {
	Thread.sleep(3000);
	capStoreSignup.setSubmit();
   
}

@Then("^switch to alert and accept it$")
public void switch_to_alert_and_accept_it() throws InterruptedException {
	Thread.sleep(2000);
	driver.switchTo().alert().accept();
    
}

@Given("^fill form data except email empty$")
public void fill_form_data_except_email_empty() throws InterruptedException {
	capStoreSignup.setName("Raushan");
	Thread.sleep(500);
	capStoreSignup.setEmail("");
	Thread.sleep(500);
	capStoreSignup.setPassword("connect2raushan");
	Thread.sleep(500);
	capStoreSignup.setAddress("Bangalore");
	Thread.sleep(500);
	capStoreSignup.setQuestion("pet name");
	Thread.sleep(500);
	capStoreSignup.setAnswer("google");
	Thread.sleep(500);
	capStoreSignup.setContact("7415417237");
	Thread.sleep(500);
	capStoreSignup.setBalance("500");
	Thread.sleep(500);
    
}

@Given("^fill form data except mobile$")
public void fill_form_data_except_mobile() throws InterruptedException {
	capStoreSignup.setName("Raushan");
	Thread.sleep(500);
	capStoreSignup.setEmail("raushanmishra@gmail.com");
	Thread.sleep(500);
	capStoreSignup.setPassword("connect2raushan");
	Thread.sleep(500);
	capStoreSignup.setAddress("Bangalore");
	Thread.sleep(500);
	capStoreSignup.setQuestion("pet name");
	Thread.sleep(500);
	capStoreSignup.setAnswer("google");
	Thread.sleep(500);
	capStoreSignup.setContact("");
	Thread.sleep(500);
	capStoreSignup.setBalance("500");
	Thread.sleep(500);
    
}

@Given("^fill form data except address$")
public void fill_form_data_except_address() throws InterruptedException {
	capStoreSignup.setName("Raushan");
	Thread.sleep(500);
	capStoreSignup.setEmail("raushanmishra@gmail.com");
	Thread.sleep(500);
	capStoreSignup.setPassword("connect2raushan");
	Thread.sleep(500);
	capStoreSignup.setAddress("");
	Thread.sleep(500);
	capStoreSignup.setQuestion("pet name");
	Thread.sleep(500);
	capStoreSignup.setAnswer("google");
	Thread.sleep(500);
	capStoreSignup.setContact("7415417237");
	Thread.sleep(500);
	capStoreSignup.setBalance("500");
	Thread.sleep(500);
   
}

@Given("^fill form data except password$")
public void fill_form_data_except_password() throws InterruptedException {
	capStoreSignup.setName("Raushan");
	Thread.sleep(500);
	capStoreSignup.setEmail("raushanmishra@gmail.com");
	Thread.sleep(500);
	capStoreSignup.setPassword("");
	Thread.sleep(500);
	capStoreSignup.setAddress("Bangalore");
	Thread.sleep(500);
	capStoreSignup.setQuestion("pet name");
	Thread.sleep(500);
	capStoreSignup.setAnswer("google");
	Thread.sleep(500);
	capStoreSignup.setContact("7415417237");
	Thread.sleep(500);
	capStoreSignup.setBalance("500");
	Thread.sleep(500);
    
}

@Given("^fill form data except question$")
public void fill_form_data_except_question() throws InterruptedException {
	capStoreSignup.setName("Raushan");
	Thread.sleep(500);
	capStoreSignup.setEmail("raushanmishra@gmail.com");
	Thread.sleep(500);
	capStoreSignup.setPassword("connect2raushan");
	Thread.sleep(500);
	capStoreSignup.setAddress("Bangalore");
	Thread.sleep(500);
	capStoreSignup.setQuestion("");
	Thread.sleep(500);
	capStoreSignup.setAnswer("google");
	Thread.sleep(500);
	capStoreSignup.setContact("7415417237");
	Thread.sleep(500);
	capStoreSignup.setBalance("500");
	Thread.sleep(500);
    
}

@Given("^fill form data except answer$")
public void fill_form_data_except_answer() throws InterruptedException {
	capStoreSignup.setName("Raushan");
	Thread.sleep(500);
	capStoreSignup.setEmail("raushanmishra@gmail.com");
	Thread.sleep(500);
	capStoreSignup.setPassword("connect2raushan");
	Thread.sleep(500);
	capStoreSignup.setAddress("Bangalore");
	Thread.sleep(500);
	capStoreSignup.setQuestion("pet name");
	Thread.sleep(500);
	capStoreSignup.setAnswer("");
	Thread.sleep(500);
	capStoreSignup.setContact("7415417237");
	Thread.sleep(500);
	capStoreSignup.setBalance("500");
	Thread.sleep(500);
    
}

@Given("^fill form data except wallet$")
public void fill_form_data_except_wallet() throws InterruptedException {
	capStoreSignup.setName("Raushan");
	Thread.sleep(500);
	capStoreSignup.setEmail("raushanmishra@gmail.com");
	Thread.sleep(500);
	capStoreSignup.setPassword("connect2raushan");
	Thread.sleep(500);
	capStoreSignup.setAddress("Bangalore");
	Thread.sleep(500);
	capStoreSignup.setQuestion("pet name");
	Thread.sleep(500);
	capStoreSignup.setAnswer("google");
	Thread.sleep(500);
	capStoreSignup.setContact("7415417237");
	Thread.sleep(500);
	capStoreSignup.setBalance("");
	Thread.sleep(500);
    
}
@After
public void closeDriver() throws InterruptedException {
	Thread.sleep(2000);
	driver.close();
}

}
